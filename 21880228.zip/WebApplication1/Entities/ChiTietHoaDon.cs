﻿namespace QLSP.Entities
{
    public class ChiTietHoaDon
    {
        public int MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuong { get; set; }
        public float Gia;

        public float ThanhTien;
    }
}
