﻿namespace QLSP.Entities
{
    public struct LoaiHang
    {
        public int MaLoaiHang;
        public string TenLoaiHang;
    }
}
