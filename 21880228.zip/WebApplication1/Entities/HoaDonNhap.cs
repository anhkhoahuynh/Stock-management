﻿namespace QLSP.Entities
{

    public struct HoaDonNhap
    {
        public int MaHoaDonNhap;
        public DateTime NgayTaoHoaDonNhap;
        public ChiTietHoaDon[] ChiTietHoaDon;
        public float TongGiaTriHoaDonNhap;
    }
}
