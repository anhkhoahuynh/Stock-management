﻿namespace QLSP.Entities
{
    public struct NguoiDung
    {
        public string TenDayDu;
        public string TenTaiKhoan;
        public string MatKhau;
    }
}
